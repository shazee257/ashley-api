module.exports = {
    email: "furniture.api@gmail.com",
    password: "otjxzhwcpxlbcuom"
    // password: "81@3w@V3hqxu"
}